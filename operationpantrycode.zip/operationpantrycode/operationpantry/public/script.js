var firebaseConfig = {
    apiKey: "AIzaSyAGdg1ySF2nm-e-XCKHBVd_e_X9ZYHnomc",
    authDomain: "operation-pantry.firebaseapp.com",
    databaseURL: "https://operation-pantry.firebaseio.com",
    projectId: "operation-pantry",
    storageBucket: "operation-pantry.appspot.com",
    messagingSenderId: "981924115480",
    appId: "1:981924115480:web:28642abcbe1b91e9ecbf6d",
    measurementId: "G-GYF802SQRV"
  };
  //initialize firebase
  firebase.initializeApp(firebaseConfig);

  let database = firebase.database()
  let ref = database.ref("operation-pantry")
  ref.on("value" , gotData , errData)

function gotData(data){
  data = data.val()
  console.log(data)
  var str = JSON.stringify(data);
  document.getElementById("insert").innerHTML = str.match(/\d+/);
}

function errData(){
  console.log(error.message , error.code)
}



$(document).ready(function() {
    var scroll_start = 0;
    var startchange = $('#startchange');
    var offset = startchange.offset();
    if (startchange.length) {
      $(document).scroll(function() {
        scroll_start = $(this).scrollTop();
        if (scroll_start > offset.top) {
          $(".navbar-default").css('background-color', '#c1292e');
        } else {
          $('.navbar-default').css('background-color', 'transparent');
        }
      });
    }
  });



